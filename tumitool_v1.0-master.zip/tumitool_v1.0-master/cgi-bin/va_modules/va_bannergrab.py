#!/usr/bin/python

#Tumi (c) 2013 va_bannergrab.py

import nmap
import cgi
import cgitb
cgitb.enable()

# GET
form   = cgi.FieldStorage()
url = form.getvalue("url")
port = form.getvalue("port")



# HTML HEADERS
print "Content-Type: text/html; charset=UTF-8"	# Print headers
print ""

# HTML 

print '''
<html>
<style>
a:link {color:#FFFFFF;}    /* unvisited link */
a:visited {color:#FFFFFF;} /* visited link */
a:hover {color:#deb054;}   /* mouse over link */
a:active {color:#deb054;}  /* selected link */
</style>
<script>
function submitit(){

var gl;
var exp;
var edb;

exp = document.getElementById("testtext").value;

gl = "https://www.google.com.pe/search?client=opera&q=" + exp + " exploit";

edb = "http://www.exploit-db.com/search/?action=search&filter_page=1&filter_description=" + exp + "&filter_exploit_text=&filter_author=&filter_platform=0&filter_type=0&filter_lang_id=0&filter_port=&filter_osvdb=&filter_cve=";

window.open(gl);
window.open(edb);

}
</script>
<body>
'''

print "<b><font color=\"White\">Banner Grabbed from Port: </font></b><br /><br /><br />"

currentScan = nmap.PortScanner()
currentScan.scan(hosts=url, arguments='-PN -sV -sC', ports=port)
hostip=str(currentScan.all_hosts()).strip('[]').replace("'","").replace("u","")

banner = "Host not found or Port closed or filtered or signature not easy even for NMAP..."

if len(hostip) > 0:
	if currentScan[hostip].state() =="up" and currentScan[hostip]['tcp'][int(port)]['state'] == "open":
		banner = str(currentScan[hostip]['tcp'][int(port)]['product']) + str(currentScan[hostip]['tcp'][int(port)]['version']) + str(currentScan[hostip]['tcp'][int(port)]['extrainfo'])
		try:
			banner = banner + str(currentScan[hostip]['tcp'][int(port)]['script'])
		except:
			pass

print "<input type=\"button\" value=\"Search Exploits @ Google And Exploit-DB\" onclick=\"submitit();\">"
print "<textarea id=\"testtext\" style=\"margin: 2px; height: 189px; width: 392px; color: White; background-color: transparent; \" autofocus>" + banner + "</textarea>"

'''
</body>
</html>
'''

