#!/usr/bin/python

import socket

host = raw_input("host")
port = raw_input("port")

maxBannerLength = 1024
def probeScan(host, port, probeString):
	s = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
	s.settimeout(6)
	try:
		s.connect((host, port))
		s.send(probeString)
		data = s.recv(maxBannerLength)

	except socket.timeout:
		print "socket.timeout exception"
 		data = ""
 	except socket.error, (value, message):
		print "socket.error " + message
		data = ""

	 # Close connection and return banner/data
 	s.close()
 	return data

probeScan(host, int(port), "")
