#!/usr/bin/python

#Tumi (c) 2013 va_nmapfullscanpn.py

import os
import datetime
import cgi
import cgitb
cgitb.enable()

# GET
form   = cgi.FieldStorage()
ip  = form.getfirst("ip")


# HTML HEADERS
print "Content-Type: text/html; charset=UTF-8"	# Print headers
print ""

# HTML 

print '''
<html>

<style>
a:link {color:#FFFFFF;}    /* unvisited link */
a:visited {color:#FFFFFF;} /* visited link */
a:hover {color:#deb054;}   /* mouse over link */
a:active {color:#deb054;}  /* selected link */
</style>

<body>
'''

now = datetime.datetime.now()

put = " ../../tumi/reports/" + "-FULLSCANPN-" + ip + "-" + str(now.year) + "-" + str(now.month) + "-" + str(now.day) + "-" + str(now.hour) + "-" + str(now.minute) + "-" + str(now.second)

nmap = "nmap -v -p- -sV -Pn --max-retries 2 " + ip + " --reason -oA" + put 


a = os.popen(nmap).read()
print "<b><font color=\"White\">Nmap 65k TCP ports: </font></b><br /><br /><br />"
print "<a href=\"" + put + ".gnmap\" target=\"_blank\">GNMAP</a>"
print "<a href=\"" + put + ".xml\" target=\"_blank\">XML</a><br /><br />"
print "<textarea style=\"margin: 2px; height: 189px; width: 392px; color: White; background-color: transparent; \">" + a + "</textarea>"
