#!/usr/bin/python

#Tumi (c) 2013 va_testsqli.py

import os
import datetime
import cgi
import cgitb
cgitb.enable()

# GET
form   = cgi.FieldStorage()
url  = form.getfirst("url")


# HTML HEADERS
print "Content-Type: text/html; charset=UTF-8"	# Print headers
print ""

# HTML 

now = datetime.datetime.now()

reportname = "../../tumi/reports/nikto-" + url + "-" + str(now.year) + "-" + str(now.month) + "-" + str(now.day) + "-" + str(now.hour) + "-" + str(now.minute) + "-" + str(now.second) + ".html"


print '''
<html>
<body>
'''

nikto = "perl ../../tumi/tools/nikto/nikto.pl -e 12345678AB -C all -D 24 -h " + url + " -maxtime 230 -p 80 -o " + reportname + "| tee /var/www/tumireports/nikto.dbg"

a = os.popen(nikto).read()

print " <textarea style=\"margin: 2px; height: 380px; width: 450px; color: white; background-color: transparent; \"> " + a + "</textarea>"
