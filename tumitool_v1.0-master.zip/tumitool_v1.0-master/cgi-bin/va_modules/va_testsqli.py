#!/usr/bin/python

#Tumi (c) 2013 va_testsqli.py

import os
import cgi
import cgitb
cgitb.enable()

# GET
form   = cgi.FieldStorage()
url  = form.getfirst("url")


# HTML HEADERS
print "Content-Type: text/html; charset=UTF-8"	# Print headers
print ""

# HTML 

print '''
<html>
<body>
'''

sqlmap = "python ../../tumi/tools/sqlmap/sqlmap.py --url=\"" + url + "\" --batch"

a = os.popen(sqlmap).read()

print " <textarea style=\"margin: 2px; height: 400px; width: 400px; color: white; background-color: transparent; \"> " + a + "</textarea>"
