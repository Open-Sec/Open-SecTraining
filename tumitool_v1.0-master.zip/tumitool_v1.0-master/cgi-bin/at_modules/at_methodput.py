#!/usr/bin/python 

#Tumi (c) 2013 at_methodput.py
 
import httplib
import cgi
import cgitb
cgitb.enable()

# GET
form   = cgi.FieldStorage()
url = form.getvalue("url")
word = form.getvalue("word")


# HTML HEADERS
print "Content-Type: text/html; charset=UTF-8"	# Print headers
print ""

# HTML 

print '''
<html>
<body>
'''
print "<textarea style=\"margin: 2px; height: 189px; width: 392px; color: green; background-color: transparent; \">"

def exists(path):
	conn1 = httplib.HTTPConnection(url)
	conn1.request('GET', path)
	response = conn1.getresponse()
	conn1.close()
	if response.status == 200:
		print url + path + " Seems Worked"
	else:
		print url + path + " Didn't Work"

conn = httplib.HTTPConnection(url)
paths = ['/imagenes/0s3c.txt','/images/0s3c.txt','/js/0s3c.txt','/css/0s3c.txt','/inc/0s3c.txt','/includes/0s3c.txt','/0s3c.txt','/files/0s3c.txt','/home/0s3c.txt','/pic/0s3c.txt','/profile_pics/0s3c.txt','/banners/0s3c.txt']

body = 'Tumi PUT Worked'

if word == "wegotaproblemdedaloxd":
	for rutas in paths:
		conn.request('PUT', rutas, body) 
		resp = conn.getresponse()
		content = resp.read()
		exists(rutas)
else:
	conn.request('PUT', word, body) 
	resp = conn.getresponse()
	content = resp.read()
	exists(word)
	#print word
print "</textarea>"

		

'''
</body>
</html>
'''
