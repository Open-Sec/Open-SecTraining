#!/usr/bin/python 

import datetime
import os
from urllib import *
import re
import socket
import urllib
import cgi
import cgitb
cgitb.enable()

# GET
form   = cgi.FieldStorage()
dominio  = form.getvalue("domain")
pro_goo = form.getvalue("pages")
pro_bing = form.getvalue("pagesb")

now = datetime.datetime.now()

name = "../tumi/reports/" + dominio + "-" + str(now.year) + "-" + str(now.month) + "-" + str(now.day) + "-" + str(now.hour) + "-" + str(now.minute) + "-" + str(now.second) + ".txt"

goo = "si"

concat_all = "==== Tumi OutPut ====\n\n"
concat_all = "Domain : "+dominio+"\n\n"

# HTML HEADERS
print "Content-Type: text/html; charset=UTF-8"	# Print headers
print ""

# HTML 

print '''
<html>
<body text="white">
'''
print "<b>Domain:"+dominio+"</b><br>"
print "<b>Report: <a href="+name+" target=new>"+dominio+"</a></b><br>"


f = "/robots.txt"    
domain = "http://" + dominio + f
try:
	packet = urllib.urlopen(domain)
	if packet.code  == 200:
		robot = urllib.urlopen(domain).read()
		robots_txt = "Robots:\n" + robot		
		concat_all = concat_all + robots_txt
		print "Output in /tumi/reports/"
	else:
		error_robot = "No Robots<br>"
		print error_robot
except:
	error_robot = "No Robots<br>"
	print error_robot

subdomain2 = ""

if goo == "si":
	p1 = int(pro_goo) + 1
	if int(pro_goo) > 0:
		print "Subdomains Found in Google:<br />"
		for numero1 in range (0,p1):

			prof1 = (numero1 * 10) + 1
			exgoo = "https://www.google.com/search?btnG=Google+Search&start=" + str(prof1) + "&q=site:" + dominio
		
			class MyOpener(FancyURLopener):
				version = 'Mozilla/5.0 (Windows; U; MSIE 7.0; Windows NT 6.0; en-US)'
	
			myopener = MyOpener()
			pag = myopener.open(exgoo)
			resgoo = pag.read()
	
			domains = []

			patron_goo = "<cite>([0-9a-zA-Z-_.]+)/</cite>"
			dirs = re.findall(patron_goo, resgoo)
			for extracted in dirs:
				if dominio in extracted and extracted not in domains:
		        		domains.append(extracted)	

			
			domains.sort()
			

	
		
			for subdomain1 in domains:
	    			print subdomain1
				subdomain2 = subdomain2 + "\n" + subdomain1

subdomain_google = "\n\nSubdomains By Google:\n\n" + subdomain2

concat_all = concat_all + subdomain_google

bing = "si"

subdominio2 = ""

try:
	domain_exist="1"
	ip = socket.gethostbyname(dominio)
except:
	domain_exist="0"
	print "The domain does not resolve IP"



if domain_exist == "1":
	dominios1 = []
	p = int(pro_bing) + 1
	if int(pro_bing) > 0:
		print "<h2>Reverse IP with BING:</h2><br />"
		for numero in range (0,p):
			prof = (numero * 10) + 1
			url_bing = "http://www.bing.com/?q=IP:" + ip + "&first=" + str(prof) + "&filt=all"
			class MyOpener1(FancyURLopener):
				version = 'Mozilla/5.0 (Windows; U; MSIE 7.0; Windows NT 6.0; en-US)'
			myopener1 = MyOpener1()
			pag_bing = myopener1.open(url_bing)
			web1 = pag_bing.read()
			pattern = "<cite>([0-9a-zA-Z-_.]+)</cite>"
			uris = re.findall(pattern, web1)
			for extracted in uris:
				if extracted not in dominios1:				
					dominios1.append(extracted)
		dominios1.sort()
		for subdominio1 in dominios1:
			subdominio2 = subdominio2 + "\n" + subdominio1

		subdomain_bing = "\n\nReverse IP By Bing:\n\n" + subdominio2
		concat_all = concat_all + subdomain_bing
		ips = "whois " + ip
		whois_op = os.popen(ips).read()
		write_whois = "\n\nWhois:\n\n" + whois_op
		concat_all = concat_all + write_whois

logfile = open(name,'w')
logfile.write(concat_all)
logfile.close()

			
print '''
</html>
</body>
'''
