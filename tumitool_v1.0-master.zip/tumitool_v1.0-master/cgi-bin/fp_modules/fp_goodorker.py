#!/usr/bin/python

#Tumi (c) 2013 fp_zt.py

import httplib, re
import cgi
import cgitb

cgitb.enable()
form   = cgi.FieldStorage()
label  = form.getfirst("label").upper()
#label viene con uno de los siguientes:
#site:dominio.com
#grupo empresarial peruano
#dominio.com -->ojo que no es lo mismo que site: para efectos como pastebin
dorks = open("../../tumi/tools/dorks.lst","r")
dorks_list = dorks.readlines()
dorks.close()


# HTML 
print "Content-Type: text/html; charset=UTF-8"	# Print headers
print ""

print '''
<html>

<style>
a:link {color:#FFFFFF;}    /* unvisited link */
a:visited {color:#FFFFFF;} /* visited link */
a:hover {color:#deb054;}   /* mouse over link */
a:active {color:#deb054;}  /* selected link */
</style>

<body>
'''


print "<b><font color=\"White\">Google Dorking Results</font></b><br /><br /><br />"

if label[:5] == "SITE:":
	leading = label.replace(":","%3A")
else:
	leading = "%22"+label.replace(" ","%20")+"%22"
	
for currentDORK in dorks_list:
	dork2run = leading+" "+str(currentDORK).replace("\n","")
	#depura = "/search?&hl=en&q="+ leading + "%20" + currentDORK + "&safe=off&filter=0"
	#print depura
	h = httplib.HTTP('www.google.com')
	h.putrequest('GET',"/search?&hl=en&q="+ leading + "%20" + currentDORK + "&safe=off&filter=0")
	h.putheader('Host', 'www.google.com')
	h.putheader('User-Agent','Mozilla/5.0 (Windows; U; Windows NT 5.1; en-US; rv:1.8.1.6) Gecko/20070725 Firefox/2.0.0.6')
	h.endheaders()
	returncode, returnmsg, headers = h.getreply()
	data=h.getfile().read()
	print data
	r1 = re.compile('<h3 class=[^>]+><a href="([^"]+)"')
	res = r1.findall(data)
	if len(res) > 0:
		print "<br /><br /><br /><b><font color=\"White\">Showing just 5 first results for dork " + dork2run + "</font></b><br />"
		for item in res[:5]:
			url=item.split('&')[0]
			url=url.split('://')[1]
			print "<a href=\"http://" + str(url) + "\" target=\"_blank\">" + str(url) + "</a><br />"
