#!/usr/bin/python

#Tumi (c) 2013 fp_robots.py

import urllib
import cgi
import cgitb
import dns.resolver
cgitb.enable()

# GET
form   = cgi.FieldStorage()
web  = form.getvalue("web")


# HTML HEADERS
print "Content-Type: text/html; charset=UTF-8"	# Print headers
print ""

# HTML 

print '''
<html>
<body>
'''


try :
	f = "/robots.txt"    
	url = "http://" + web + f
	packet = urllib.urlopen(url)
	if packet.code  == 200:
		msg = "<b><font color=\"White\">Si tiene Robots</font></b><br /><br /><br />"
		robot = urllib.urlopen(url).read()
		print msg		
		print "<textarea style=\"margin: 2px; height: 189px; width: 392px; color: White; background-color: transparent; \">" + robot + "</textarea>"
	else:
		msg = "<b><font color=\"Red\"> Robots doesn't exist</font></b><br />"
		print msg

except :
	msg = "<b><font color=\"Red\"> Host NOT Found !</font></b><br />"
	print msg
		
print '''
</html>
</body>
'''
