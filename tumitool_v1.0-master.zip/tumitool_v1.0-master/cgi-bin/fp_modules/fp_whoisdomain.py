#!/usr/bin/python

#Tumi (c) 2013 fp_whoisdomain.py

import os
import cgi
import cgitb
cgitb.enable()

# GET
form   = cgi.FieldStorage()
dominio  = form.getfirst("domain")


# HTML HEADERS
print "Content-Type: text/html; charset=UTF-8"	# Print headers
print ""

# HTML 

print '''
<html>
<body>
'''

dominiope = dominio[-3:]
if dominiope == ".pe":
	domain = "whois " + dominio + " -h kero.yachay.pe"
else:
	domain = "whois " + dominio


a = os.popen(domain).read()
print "<b><font color=\"White\">Domain Whois</font></b><br /><br /><br />"
print "<textarea style=\"margin: 2px; height: 189px; width: 392px; color: White; background-color: transparent; \">" + a + "</textarea>"
