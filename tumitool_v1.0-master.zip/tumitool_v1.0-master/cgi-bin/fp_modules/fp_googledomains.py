#!/usr/bin/python

#Tumi (c) 2013 fp_googledomains.py

from urllib import *
import urllib
import re
import socket
import cgi
import cgitb
cgitb.enable()

# GET
form   = cgi.FieldStorage()
domain  = form.getvalue("domain")
page_goo = form.getvalue("pages")
goo = "si";

# HTML HEADERS
print "Content-Type: text/html; charset=UTF-8"	# Print headers
print ""

# HTML 

print '''
<html>
<body>
'''


if goo == "si":
	p1 = int(page_goo) + 1
	if int(page_goo) > 0:
		print "<b><font color=\"White\">Subdomains Found in Google</font></b><br /><br /><br />"
		print "<textarea style=\"margin: 2px; height: 189px; width: 392px; color: White; background-color: transparent; \">"
		for count in range (0,p1):

			prof1 = (count * 10) + 1
			exgoo = "https://www.google.com/search?btnG=Google+Search&start=" + str(prof1) + "&q=site:" + domain
		
			opener = urllib.FancyURLopener({})
			opener.addheaders = [('User-agent','Mozilla/5.0 (Windows; U; MSIE 7.0; Windows NT 6.0; en-US)')]
			page = opener.open(exgoo)
			resgoo = page.read()
	
			domains = []

			pattern_goo = "<cite>([0-9a-zA-Z-_.]+)/</cite>"
			dirs = re.findall(pattern_goo, resgoo)
			for extracted in dirs:
				if domain in extracted and extracted not in domains:
		        		domains.append(extracted)	

			domains.sort()
			for subdomain1 in domains:
	    			print "[+] %s" % subdomain1
		
		print "</textarea>"
				

