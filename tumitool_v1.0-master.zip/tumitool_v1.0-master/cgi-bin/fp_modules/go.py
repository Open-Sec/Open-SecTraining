import httplib, re

dominio = "gob.pe"
currentDORK = "intitle%3Aindex.of+admin"

h = httplib.HTTP('www.google.com')
h.putrequest('GET',"/search?&hl=en&q=site%3A"+ dominio + "+"+ currentDORK + "&safe=off&filter=0")
h.putheader('Host', 'www.google.com')
h.putheader('User-Agent','Mozilla/5.0 (Windows; U; Windows NT 5.1; en-US; rv:1.8.1.6) Gecko/20070725 Firefox/2.0.0.6')
#h.putheader('User-agent', 'Internet Explorer 6.0 ')
h.endheaders()
returncode, returnmsg, headers = h.getreply()
#print returncode
#print returnmsg
#print headers
data=h.getfile().read()
r1 = re.compile('<h3 class=[^>]+><a href="([^"]+)"')
res = r1.findall(data)
print len(res)
for item in res[:5]:
	url=item.split('&')[0]
	url=url.split('://')[1]
	print "http://"+url+"<br>"
	
