#!/usr/bin/python 

from docx import *
import datetime
import os
from urllib import *
import re
import socket
import urllib
import cgi
import cgitb
cgitb.enable()

# GET
form   = cgi.FieldStorage()
dominio  = form.getvalue("domain")
pro_goo = form.getvalue("pages")
pro_bing = form.getvalue("pagesb")
client = form.getvalue("client")
consultor = form.getvalue("consultant")


now = datetime.datetime.now()

name = "../../tumi/reports/" + dominio + "-" + str(now.year) + "-" + str(now.month) + "-" + str(now.day) + "-" + str(now.hour) + "-" + str(now.minute) + "-" + str(now.second) + ".txt"

goo = "si"

concat_all = "==== Tumi OutPut ====\n\n"

relationships = relationshiplist()
document = newdocument()
body = document.xpath('/w:document/w:body', namespaces=nsprefixes)[0]


# HTML HEADERS
print "Content-Type: text/html; charset=UTF-8"	# Print headers
print ""

# HTML 

print '''
<html>
<body>
'''

body.append(heading("FingerPrinted Domains Found", 1))

body.append(heading("", 1))

cli = "<b>Client:</b> " + client

body.append(heading(cli, 2))

cons = "Consultant: " + consultor

body.append(heading(cons, 2))

body.append(heading("Ubicacion: Externa", 2))



def robots(site):
	global concat_all
	f = "/robots.txt"    
	domain = "http://" + site + f
	packet = urllib.urlopen(domain)
	if packet.code  == 200:
		robot = urllib.urlopen(domain).read()
		robots_txt = "\n Robots from " + domain +  ":\n" + robot		
		concat_all = concat_all + robots_txt
		return robots_txt

	else:
		error_robot = "No Robots"


robots(dominio)

subdomain2 = ""


body.append(heading("", 1))

body.append(heading("Subdomains With Google", 2))


if goo == "si":
	p1 = int(pro_goo) + 1
	if int(pro_goo) > 0:
		#ws.write(0,0,"Subdomains Found in Google:")
		for numero1 in range (0,p1):

			prof1 = (numero1 * 10) + 1
			exgoo = "https://www.google.com/search?btnG=Google+Search&start=" + str(prof1) + "&q=site:" + dominio
		
			class MyOpener(FancyURLopener):
				version = 'Mozilla/5.0 (Windows; U; MSIE 7.0; Windows NT 6.0; en-US)'
	
			myopener = MyOpener()
			pag = myopener.open(exgoo)
			resgoo = pag.read()
	
			domains = []

			patron_goo = "<cite>([0-9a-zA-Z-_.]+)/</cite>"
			dirs = re.findall(patron_goo, resgoo)
			for extraidos in dirs:
				if dominio in extraidos and extraidos not in domains:
		        		domains.append(extraidos)	

			
			domains.sort()
			

			ldomain = len(domains)
			cf = 0
			for subdomain1 in domains:
				cf = cf + 1
				a = socket.gethostbyname(subdomain1)
				tbl_rows = [ [str(cf),subdomain1,str(a)]
					   ]

				body.append(table(tbl_rows))



bing = "si"

subdominio2 = ""

body.append(heading("", 1))

body.append(heading("Subdomains With BING", 2))


if bing == "si":
	dominios1 = []
	p = int(pro_bing) + 1
	if int(pro_bing) > 0:
		#ws.write(0,1,"Subdomains Found with Bing:")

		ip = socket.gethostbyname(dominio)
		for numero in range (0,p):

			prof = (numero * 10) + 1



			url_bing = "http://www.bing.com/?q=IP:" + ip + "&first=" + str(prof) + "&filt=all"


			class MyOpener1(FancyURLopener):
				version = 'Mozilla/5.0 (Windows; U; MSIE 7.0; Windows NT 6.0; en-US)'
 

			myopener1 = MyOpener1()
			pag_bing = myopener1.open(url_bing)
			web1 = pag_bing.read()
			

			pattern = "<cite>([0-9a-zA-Z-_.]+)</cite>"
			uris = re.findall(pattern, web1)
			for extracted in uris:
				if extracted not in dominios1:				
					dominios1.append(extracted)

	
		dominios1.sort()
		ldomain1 = len(dominios1)
		cfb = 0
			
		for subdominio1 in dominios1:
			cfb = cfb + 1
			a = robots(subdominio1)
			tbl_rowsb = [ [str(cfb),subdominio1]
				   ]
			body.append(table(tbl_rowsb))


wlist = ["updates","help","company","flirt"]

def pingwordlist(URI): # wordlist by array
    body.append(heading("", 1))
    body.append(heading("Subdomains With Dictionary", 2))
    qc = 0
    for line in wlist:
        try:
            s = socket.gethostbyname(line + "." + URI)
            if s:
		qc = qc + 1
                subdomain337 = line+"."+URI
		tbl_rowsb = [ [str(qc),subdomain337, s]
		            ]
		body.append(table(tbl_rowsb))
                s.close()
        except:
            pass

pingwordlist(dominio)

ips = "whois " + ip

whois_op = os.popen(ips).read()

write_whois = "\n\nWhois:\n\n" + whois_op

concat_all = concat_all + write_whois

nuts = name + ".docx"

    # Create our properties, contenttypes, and other support files
title    = 'Tumi - FingerPrint'
subject  = 'Python Tumi Tool Fingerprint'
creator  = 'Dedalo'
keywords = ['Peruvian', 'tool', 'tumi']

coreprops = coreproperties(title=title, subject=subject, creator=creator,
                               keywords=keywords)
appprops = appproperties()
contenttypes = contenttypes()
websettings = websettings()
wordrelationships = wordrelationships(relationships)

    # Save our document
savedocx(document, coreprops, appprops, contenttypes, websettings,
             wordrelationships, nuts)


print "<textarea id=\"testtext\" style=\"margin: 2px; height: 189px; width: 392px; color: White; background-color: transparent; \"> Done Check The reports</textarea>"
			
print '''
</html>
</body>
'''
