#!/usr/bin/python

#Tumi (c) 2013 fp_whoisipcalc.py

import os, StringIO, ipcalc, cgi, cgitb
cgitb.enable()

# GET
form   = cgi.FieldStorage()
ipv4  = form.getfirst("ip")


# HTML HEADERS
print "Content-Type: text/html; charset=UTF-8"  # Print headers
print ""

# HTML 

print '''
<html>
<body>
'''


whois = "whois "+ ipv4

a = os.popen(whois).read()

todas_las_lineas = StringIO.StringIO(a)

#Mensaje default ante cualquier resultado no parseado por este modulo
msg = "Try other Whois modules from Tumi..."

for cada_linea in todas_las_lineas:
	#Separa por slash para sacar la mascara
	delimitador1 = cada_linea.split('/')
	
	#Separa por dos puntos para sacar la IP/mascara
	delimitador2 = cada_linea.split(':')
	#Busca la linea inetnum:
	linea_inetnum = str(delimitador1[0:1]).strip('[]').replace("'","")[:8]
		
	#Valida si los primeros 8 chars dicen inetnum: porque asi identica que es la linea con la info
	if linea_inetnum == "inetnum:":
		mascara = str(delimitador1[1:2]).strip('[]').replace("'","")[:2]
		#print mascara
		#Valida si es una supernet...
		if int(mascara) < 24 :
			msg = "This a Supernet, try with other Fingerprint modules."
			#exit()
		else:
			inetnum =ipcalc.Network(str(delimitador2[1:2]).strip('[]').replace("'","").replace("\\n",""))
			delimitador3 = cada_linea.split('.')
			fourthOCTETO = str(delimitador3[2:3]).strip('[]').replace("'","")
			#print fourthOCTETO
			msg = " "
			if fourthOCTETO.find('/') != -1:
				msg = "inetnum field has FOURTH octet registered as ZERO"
			msg = msg + "\nFirst Host IP Address: "+str(inetnum.host_first())+"\nLast Host IP Address: "+str(inetnum.host_last())+"\nMax hosts in this subnet : "+str(inetnum.size()-2)
		
print "<b><font color=\"White\">Domain Whois</font></b><br /><br /><br />"
print "<textarea style=\"margin: 2px; height: 189px; width: 392px; color: White; background-color: transparent; \">" + msg + "</textarea>"