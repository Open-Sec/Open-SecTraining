#!/usr/bin/python

#Tumi (c) 2013 fp_discover_ext.py
	   
import dns.query
import dns.zone
import dns.resolver
import ipcalc
import os
import StringIO
import datetime
import cgi
import cgitb
cgitb.enable()

# GET
form   = cgi.FieldStorage()
hostname  = form.getvalue("hostname")
consultant = form.getvalue("consultant")
customer = form.getvalue("customer")

now = datetime.datetime.now()

reportname = "../../tumi/reports/" + hostname + "-" + str(now.year) + "-" + str(now.month) + "-" + str(now.day) + "-" + str(now.hour) + "-" + str(now.minute) + "-" + str(now.second) + ".html"


CleanStop = False
#hostname = sys.argv[1]

report = open(reportname,'w')

#HTML HEADERS
print "Content-Type: text/html; charset=UTF-8"	# Print headers
print ""

# HTML 
print '''
<html>
<body>
'''

report.write("<html><body>")

report.write("<b><font color=\"Blue\">EXTERNAL DISCOVERY REPORT</font></b><br /><br /><br />")

report.write("<b><font color=\"Green\">CUSTOMER : </font></b>" + customer + "<br>")
report.write("<b><font color=\"Green\">DATE : </font></b>" + str(now) + "<br>")
report.write("<b><font color=\"Green\">CONSULTANT : </font></b>" + consultant + "<br><br>")

try :
	buscaHOST = dns.resolver.query(hostname)
	
	whois = "whois "+ str(buscaHOST[0])
	
	a = os.popen(whois).read()

	todas_las_lineas = StringIO.StringIO(a)	

	#Mensaje default ante cualquier resultado no parseado por este modulo
	msg = "<font color=\"White\">Got no exact WHOIS info...going for Zone Transfer...</font><BR>"
		
	for cada_linea in todas_las_lineas:
		#Separa por slash para sacar la mascara
		delimitador1 = cada_linea.split('/')
	
		#Separa por dos puntos para sacar la IP/mascara
		delimitador2 = cada_linea.split(':')
		#Saca el string "inetnum:" o "CIDR:"
		linea_inetnum = str(delimitador1[0:1]).strip('[]').replace("'","")[:8]
		
		#Valida si los primeros 8 chars dicen inetnum: o CIDR: porque asi identica que es la linea con la info
		if linea_inetnum == "inetnum:" or linea_inetnum == "CIDR:":
			mascara = str(delimitador1[1:2]).strip('[]').replace("'","")[:2]
			#print mascara
			#Valida si es una supernet...
			if len(mascara) > 0:
				if int(mascara) < 24 :
					msg = "<font color=\"White\">This a Supernet, try with other Fingerprint modules.</font><BR>"
					#exit()
				else:
					#report = open('report.txt','w')
					report.write ("<b>Data in WHOIS database ===></b><BR><BR>")
					inetnum =ipcalc.Network(str(delimitador2[1:2]).strip('[]').replace("'","").replace("\\n",""))
					delimitador3 = cada_linea.split('.')
					fourthOCTETO = str(delimitador3[2:3]).strip('[]').replace("'","")
					#print fourthOCTETO
					msg = " "
					if fourthOCTETO.find('/') != -1:
						msg = "<font color=\"White\">inetnum/CIDR field has FOURTH octet registered as ZERO </font><BR>"
					msg = msg + "<BR>First Host IP Address: <b>"+str(inetnum.host_first())+"</b><BR>Last Host IP Address: <b>"+str(inetnum.host_last())+"</b><BR>Max hosts in this subnet : <b>"+str(inetnum.size()-2)+"</b><BR>"
					report.write(msg)
					#report.close()
					CleanStop = True
					exit()
			else:
				msg = "<font color=\"White\">inetnum/CIDR not found or format not recognized...Let's try Zone Transfer...</font><BR>"
	print msg
	try:
		#1. encontrar servidor dns
		dominioS = str (dns.name.from_text(hostname).parent())
		buscaNS = dns.resolver.query(dominioS, 'NS')
		ns1 = buscaNS[0]
		ns2 = buscaNS[1]

		#2. intentar zone transfer
		try :
			transfiereZONA = dns.zone.from_xfr(dns.query.xfr(str(ns1), dominioS, timeout=5, lifetime=10))
			nombresDNS = transfiereZONA.nodes.keys()
			nombresDNS.sort()
			#report = open('report.txt','w')
			report.write("<b>ZONE TRANSFER ANSWER ===> </b><BR><BR>")
			for hosts in nombresDNS:
				report.write(transfiereZONA[hosts].to_text(hosts)+"<BR>")
			#report.close()
			CleanStop = True
			exit()
		except :
			if not CleanStop:
				print "<font color=\"White\">Zone Transfer failed.  Cool! Let's try dns mapping...</font><BR>"
				#exit()
	
		if not CleanStop:
			#3. hacer busqueda con diccionario
			dictionary = open("../../tumi/tools/nombreshosts.dict","r+")
			todas_las_lineas = dictionary.readlines()
			dictionary.close()
			
			CleanStop = True
			#report = open("report.txt","w")
			report.write("<b>DNS MAPPING RESULTS ===> </b><BR><BR>")
			for host in todas_las_lineas:
				node = host.replace("\n","") + "." + dominioS
				try:
					buscaHOST = dns.resolver.query(node)
					report.write("Found Node! : " + node + "-->" + str(buscaHOST[0]) + "<BR>")
				except:
					pass
			#report.close()
			exit()
	except :
		if not CleanStop:
			msg = "<b><font color=\"Red\"> Enter a valid Host Name!</font></b><br />"
			print msg
except :
	if not CleanStop:
		msg = "<b><font color=\"Red\"> Host NOT Found !</font></b><br />"
		print msg
		exit

print "<a target=new href=/tumi/reports/" + str(os.path.basename(reportname)) +" >Done! Click here to check the External Discovery Report </a>"

report.write('''
</html>
</body>
''')
report.close()

print '''
</html>
</body>
'''
