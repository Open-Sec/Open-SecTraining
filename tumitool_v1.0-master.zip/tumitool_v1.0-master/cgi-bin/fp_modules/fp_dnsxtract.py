#!/usr/bin/python
import dns.query
import dns.zone
import dns.resolver
import cgi, cgitb
cgitb.enable()

# GET
form   = cgi.FieldStorage()
dominio  = form.getfirst("domain")

# HTML HEADERS
print "Content-Type: text/html; charset=UTF-8"  # Print headers
print ""

# HTML 

print '''
<html>
<body>
'''

print dominio
#1. encontrar servidor dns
try :
	buscaNS = dns.resolver.query(dominio, 'NS')
	ns1 = buscaNS[0]
	ns2 = buscaNS[1]
	ns1_ip = dns.resolver.query(str(ns1))
	
	#2. intentar zone transfer
	try :
		transfiereZONA = dns.zone.from_xfr(dns.query.xfr(str(ns1), dominio, timeout=5, lifetime=10))
		nombresDNS = transfiereZONA.nodes.keys()
		nombresDNS.sort()
		print "<b><font color=\"White\">ZONE TRANFER You got the full package!</font></b><br /><br /><br />"
		print "<textarea style=\"margin: 2px; height: 360px; width: 360px; color: White; background-color: transparent; \">"
		for hosts in nombresDNS:
			print transfiereZONA[hosts].to_text(hosts)
		print "</textarea>"
	except :
		#print "Zone Transfer failed.  Cool!"
		print "<b><font color=\"White\">Zone Transfer failed.  Cool!...not full package...sorry</font></b><br /><br /><br />"
		print "<textarea style=\"margin: 2px; height: 360px; width: 360px; color: White; background-color: transparent; \">"
	
		#3. hacer busqueda con diccionario
		dictionary = open("../../tumi/tools/nombreshosts.dict","r+")
		todas_las_lineas = dictionary.readlines()
		dictionary.close()

		#Que no lea /etc/resolv.conf
		resolverinstance = dns.resolver.Resolver(configure=False)
		#Convertir elemento de lista en string y luego armar la otra lista porque debe ser una lista de strings.
	        resolverinstance.nameservers = [str(ns1_ip[0]),]	

		for host in todas_las_lineas:
			node = host.replace("\n","") + "." + dominio
			try :
				buscaHOST = resolverinstance.query(node)
				print "Found Node! : \n" + node + "-->" + str(buscaHOST[0])
			except:
				pass
		print "</textarea>"

except :
	msg = "<b><font color=\"Red\"> Enter a Domain name!</font></b><br />"
	print msg


		
	
	




