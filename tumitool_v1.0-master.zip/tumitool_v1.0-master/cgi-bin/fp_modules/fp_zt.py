#!/usr/bin/python

#Tumi (c) 2013 fp_zt.py

import dns.resolver
import dns.query
import dns.zone
import cgi
import cgitb
cgitb.enable()

form   = cgi.FieldStorage()
domain  = form.getfirst("domain")

print "Content-Type: text/html; charset=UTF-8"	# Print headers
print ""

# HTML 

print '''
<html>
<body>
'''



def zonetransfer(dominio):
	print "<b><font color=\"White\">Testing Zone Transfer: </font></b><br /><br /><br />"
	answers = dns.resolver.query(dominio, 'NS')
	for rdata in answers:
		n = str(rdata)
		try:
			z = dns.zone.from_xfr(dns.query.xfr(n, dominio))
			names = z.nodes.keys()
			names.sort()
			for n in names:			
				print z[n].to_text(n) + "<br />"
		except:
			pass

zonetransfer(domain)
