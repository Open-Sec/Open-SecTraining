#!/usr/bin/python

#Tumi (c) 2013 fp_domaingatheringbylink.py

from urllib import *
import urllib
import re
import socket
import cgi
import cgitb
cgitb.enable()

# GET
form   = cgi.FieldStorage()
url = form.getvalue("url")
dominio  = form.getvalue("domain")

# Web
web = urllib.urlopen(url).read()

#Operation

dominios = []

patron = "https?://([0-9a-zA-Z-_.]+)"
urls = re.findall(patron, web)
for extraida in urls:
    if dominio in extraida and extraida not in dominios:
        dominios.append(extraida)


# HTML HEADERS
print "Content-Type: text/html; charset=UTF-8"	# Print headers
print ""

# HTML 

print '''
<html>
<body>
'''
dominios.sort()
print "<b><font color=\"White\">Subdomain gathering from website:</font></b><br /><br /><br />"
print "<textarea style=\"margin: 2px; height: 189px; width: 392px; color: White; background-color: transparent; \">"
for subdominio in dominios:
	print "[+] %s" % subdominio

print "</textarea>"
