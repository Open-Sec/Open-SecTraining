#!/usr/bin/python

#Tumi (c) 2013 fp_bingreverseip.py

from urllib import *
import urllib
import re
import socket
import cgi
import cgitb
cgitb.enable()

# GET
form   = cgi.FieldStorage()
dominio  = form.getvalue("hostname")
pro_bing = form.getvalue("pages")
bing = "si";

# HTML HEADERS
print "Content-Type: text/html; charset=UTF-8"	# Print headers
print ""

# HTML 

print '''
<html>

<style>
a:link {color:#FFFFFF;}    /* unvisited link */
a:visited {color:#FFFFFF;} /* visited link */
a:hover {color:#deb054;}   /* mouse over link */
a:active {color:#deb054;}  /* selected link */
</style>

<body>
'''

if bing == "si":
	dominios = []
	p = int(pro_bing) + 1
	if int(pro_bing) > 0:
		print "<b><font color=\"White\">Reverse IP With Bing</font></b><br /><br /><br />"
		try:
			ip = socket.gethostbyname(dominio)
			for numero in range (0,p):
				prof = (numero * 10) + 1
				url_bing = "http://www.bing.com/?q=IP:" + ip + "&first=" + str(prof) + "&filt=all"				
 
				opener = urllib.FancyURLopener({})
				opener.addheaders = [('User-agent','Mozilla/5.0 (Windows; U; MSIE 7.0; Windows NT 6.0; en-US)')]
				pag_bing = opener.open(url_bing)
				web1 = pag_bing.read()
			

				pattern = "<cite>([0-9a-zA-Z-_.]+)</cite>"
				uris = re.findall(pattern, web1)
				for extracted in uris:
					if extracted not in dominios:				
						dominios.append(extracted)

	
				dominios.sort()
				for subdominio in dominios:
					print "<a href=\"http://" + subdominio + "\">" + subdominio + "</a><br />"
		except:
			print "<b><font color=\"Red\">Hostname IP address NOT found</font></b><br /><br /><br />"