#!/usr/bin/python

#Tumi (c) 2013 fp_whoisip.py

import os
import cgi
import cgitb


# GET
form   = cgi.FieldStorage()
ip  = form.getfirst("ip")

cgitb.enable()

# HTML HEADERS
print "Content-Type: text/html; charset=UTF-8"	# Print headers
print ""

# HTML 

print '''
<html>
<body>
'''

ips = "whois " + ip

a = os.popen(ips).read()
print "<b><font color=\"White\">Whois</font></b><br /><br /><br />"
print "<textarea style=\"margin: 2px; height: 189px; width: 392px; color: White; background-color: transparent; \">" + a + "</textarea>"
