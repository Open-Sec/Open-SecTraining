#!/usr/bin/python 

#Tumi (c) 2013 fp_getlinks.py

import urllib2
import re
import cgi
import cgitb

form   = cgi.FieldStorage()
url = form.getvalue("url")
domain  = form.getvalue("dom")
cgitb.enable()

# HTML 
print "Content-Type: text/html; charset=UTF-8"	
print ""


print '''
<html>
<body>
'''
print "<textarea style=\"margin: 2px; height: 189px; width: 392px; color: green; background-color: transparent; \">"

page = urllib2.urlopen(url)
page = page.read()
links = re.findall(r"<a.*?\s*href=\"(.*?)\".*?>(.*?)</a>", page)

links_total = []

for link in links:
	if domain in link[0] and link[0] not in links_total:
		links_total.append(link[0])

for plinks in links_total:
	print plinks + "\n"
			
print "</textarea>"

'''
</body>
</html>
'''
